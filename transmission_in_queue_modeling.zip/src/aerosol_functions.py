"""
Aerosol transmission model functions for queue dynamics analysis.

This module contains the computational functions for modeling airborne particle
transmission in queue settings, including:
- Core mathematical primitives (Green's functions)
- Numerical integration routines using Gauss-Legendre quadrature
- Queue position dynamics
- Particle number calculations

"""

import math
import numpy as np
from numba import njit, prange
from typing import Tuple

# ------------------------------
# Gauss-Legendre nodes & weights (n=16) on [-1, 1]
# ------------------------------
_GLX16 = np.array([
    -0.9894009349916499, -0.9445750230732326, -0.8656312023878317, -0.7554044083550030,
    -0.6178762444026438, -0.4580167776572274, -0.2816035507792589, -0.09501250983763744,
     0.09501250983763744,  0.2816035507792589,  0.4580167776572274,  0.6178762444026438,
     0.7554044083550030,  0.8656312023878317,  0.9445750230732326,  0.9894009349916499
], dtype=np.float64)

_GLW16 = np.array([
    0.027152459411754095, 0.06225352393864789, 0.09515851168249278, 0.12462897125553387,
    0.14959598881657673, 0.16915651939500254, 0.1826034150449236,  0.1894506104550685,
    0.1894506104550685,  0.1826034150449236,  0.16915651939500254, 0.14959598881657673,
    0.12462897125553387, 0.09515851168249278, 0.06225352393864789, 0.027152459411754095
], dtype=np.float64)

# ------------------------------
# Gauss-Legendre nodes & weights (n=32) on [-1, 1]
# ------------------------------
_GLX32 = np.array([
    -0.997263861849, -0.985611511545, -0.964762255588, -0.934906075938,
    -0.896321155766, -0.849367613733, -0.794483795968, -0.732182118740,
    -0.663044266930, -0.587715757241, -0.506899908932, -0.421351276131,
    -0.331868602282, -0.239287362252, -0.144471961583, -0.048307665688,
     0.048307665688,  0.144471961583,  0.239287362252,  0.331868602282,
     0.421351276131,  0.506899908932,  0.587715757241,  0.663044266930,
     0.732182118740,  0.794483795968,  0.849367613733,  0.896321155766,
     0.934906075938,  0.964762255588,  0.985611511545,  0.997263861849
], dtype=np.float64)

_GLW32 = np.array([
    0.007018610009, 0.016274394715, 0.025392065309, 0.034273862913,
    0.042835898022, 0.050998059262, 0.058684093479, 0.065822222776,
    0.072345794109, 0.078193895787, 0.083311924227, 0.087652093004,
    0.091173878696, 0.093844399081, 0.095638720079, 0.096540088515,
    0.096540088515, 0.095638720079, 0.093844399081, 0.091173878696,
    0.087652093004, 0.083311924227, 0.078193895787, 0.072345794109,
    0.065822222776, 0.058684093479, 0.050998059262, 0.042835898022,
    0.034273862913, 0.025392065309, 0.016274394715, 0.007018610009
], dtype=np.float64)

# ------------------------------
# Core Green's function primitive
# ------------------------------
@njit(cache=True, fastmath=True)
def _g(m: int, t: float, l: float, a: float) -> float:
    """
    Core Green's function primitive for diffusion-advection-decay equation.
    
    Parameters
    ----------
    m : int
        step index
    t : float
        Time variable (dimensionless)
    l : float
        Spatial period (dimensionless)
    a : float
        Spatial offset (dimensionless)
        
    Returns
    -------
    float
        Green's function value
    """
    A = abs(m * l - a)
    
    # Guards to avoid singular/overflow behavior
    if A > 70.0:
        return 0.0
    if t < 1e-6:
        return 0.0
    if A < 1e-12:
        return 0.0
    
    rt = math.sqrt(t)
    e4A = math.exp(4.0 * A)
    term = 1.0 - e4A + math.erf((A - t) / rt) + e4A * math.erf((A + t) / rt)
    y = -(math.exp(-2.0 * A) * math.sqrt(math.pi) * term) / (2.0 * A)
    return y

# ------------------------------
# Integrand for stepped queue dynamics
# ------------------------------
@njit(cache=True, fastmath=True)
def _integrand_tau(tau: float, seg_index: int, Ts: float, l: float, a: float, 
                   eps: float, M: int = 10) -> float:
    """
    Integrand for segment-wise integration with multiple image sources.
    
    Parameters
    ----------
    tau : float
        Integration variable within segment
    seg_index : int
        Current segment index (0-based)
    Ts : float
        Step duration (dimensionless)
    l : float
        Spatial step size (dimensionless)
    a : float
        Forward offset distance (dimensionless)
    eps : float
        Small regularization parameter
    M : int, optional
        Maximum number of steps to consider, by default 10
        
    Returns
    -------
    float
        Integrand value
    """
    mmax = min(seg_index, M)
    
    y = _g(-1, tau, l, a) - _g(-1, eps, l, a)
    for m in range(mmax + 1):
        y += _g(m, tau + (m + 1) * Ts, l, a) - _g(m, tau + m * Ts, l, a)
    return y

# ------------------------------
# Single segment Gauss-Legendre integration
# ------------------------------
@njit(cache=True, fastmath=True)
def _integrate_segment(seg_index: int, Ts: float, l: float, a: float, eps: float,
                       seg_len: float, glx: np.ndarray, glw: np.ndarray, 
                       M: int = 10) -> float:
    """
    Integrate over a single time segment using Gauss-Legendre quadrature.
    
    Parameters
    ----------
    seg_index : int
        Segment index
    Ts : float
        Step duration
    l : float
        Spatial step size
    a : float
        Forward offset
    eps : float
        Regularization parameter
    seg_len : float
        Length of this segment
    glx : np.ndarray
        Gauss-Legendre nodes
    glw : np.ndarray
        Gauss-Legendre weights
    M : int, optional
        Maximum steps to consider, by default 10
        
    Returns
    -------
    float
        Integrated value over segment
    """
    if seg_len <= 0.0:
        return 0.0
    half = 0.5 * seg_len
    mid = 0.5 * seg_len
    acc = 0.0
    for i in range(glx.size):
        tau = half * glx[i] + mid
        acc += glw[i] * _integrand_tau(tau, seg_index, Ts, l, a, eps, M)
    return half * acc

# ------------------------------
# Total integral with period averaging
# ------------------------------
@njit(cache=True, fastmath=True)
def _integrate_total(T: float, Ts: float, l: float, a: float, eps: float,
                     glx: np.ndarray, glw: np.ndarray, M: int = 10) -> float:
    """
    Compute total integral over [0, T] with period averaging after saturation.
    
    
    Parameters
    ----------
    T : float
        Total observation time
    Ts : float
        Step duration
    l : float
        Spatial step size
    a : float
        Forward offset
    eps : float
        Regularization parameter
    glx : np.ndarray
        Gauss-Legendre nodes
    glw : np.ndarray
        Gauss-Legendre weights
    M : int, optional
        Maximum steps to consider, by default 10
        
    Returns
    -------
    float
        Total integrated concentration
    """
    if T <= 0.0:
        return 0.0
    
    total = 0.0
    
    # Initial segments until mmax reaches M
    max_unsat = M
    n_segments = int(T // Ts)
    n_init = n_segments if n_segments < max_unsat else max_unsat
    
    for s in range(n_init):
        seg_start = s * Ts
        seg_end = seg_start + Ts
        if seg_end > T:
            seg_end = T
        seg_len = seg_end - seg_start
        if seg_len > 0.0:
            total += _integrate_segment(s, Ts, l, a, eps, seg_len, glx, glw, M)
    
    t_done = n_init * Ts
    if t_done >= T:
        return total
    
    # After saturation: use fixed seg_index = M (periodic behavior)
    s_sat = M
    period_val = _integrate_segment(s_sat, Ts, l, a, eps, Ts, glx, glw, M)
    
    t_left = T - t_done
    n_full = int(t_left // Ts)
    total += n_full * period_val
    
    rem = t_left - n_full * Ts
    if rem > 0.0:
        total += _integrate_segment(s_sat, Ts, l, a, eps, rem, glx, glw, M)
    
    return total

# ------------------------------
# Vectorized computation over step durations
# ------------------------------
@njit(parallel=True, cache=True, fastmath=True)
def compute_Q_over_Tss(Tss: np.ndarray, T: float, A: float, a: float, eps: float,
                       glx: np.ndarray, glw: np.ndarray, M: int = 10) -> np.ndarray:
    """
    Compute inhaled particle concentration Q(Ts) for all step durations in parallel.
    
    Parameters
    ----------
    Tss : np.ndarray
        Array of dimensionless step durations
    T : float
        Total observation time
    A : float
        Spatial separation between people
    a : float
        Forward offset distance
    eps : float
        Regularization parameter
    glx : np.ndarray
        Gauss-Legendre nodes
    glw : np.ndarray
        Gauss-Legendre weights
    M : int, optional
        Maximum image sources, by default 10
        
    Returns
    -------
    np.ndarray
        Concentration values for each step duration
    """
    Q = np.zeros(Tss.size, dtype=np.float64)
    for i in prange(Tss.size):
        Ts = Tss[i]
        Q[i] = _integrate_total(T, Ts, A, a, eps, glx, glw, M)
    return Q

# ------------------------------
# Figure 2 specific: multiple distances
# ------------------------------
@njit(parallel=True, cache=True, fastmath=True)
def compute_results_multiple_a(Tss: np.ndarray, a_vals: np.ndarray, T: float, 
                               l: float, eps: float, glx: np.ndarray, 
                               glw: np.ndarray) -> np.ndarray:
    """
    Compute results for multiple forward offset distances (Figure 4C).
    
    Parameters
    ----------
    Tss : np.ndarray
        Step durations
    a_vals : np.ndarray
        Forward offset distances
    T : float
        Total time
    l : float
        Spatial step size
    eps : float
        Regularization
    glx : np.ndarray
        GL nodes
    glw : np.ndarray
        GL weights
        
    Returns
    -------
    np.ndarray
        Array of shape (len(Tss), len(a_vals))
    """
    out = np.zeros((Tss.size, a_vals.size), dtype=np.float64)
    for j in prange(a_vals.size):
        a = a_vals[j]
        for i in range(Tss.size):
            Ts = Tss[i]
            out[i, j] = _integrate_total(T, Ts, l, a, eps, glx, glw, 10)
    return out

# ------------------------------
# Queue position dynamics
# ------------------------------
@njit(cache=True, fastmath=True)
def _pos(t: float, l: float, Ts: float, n: int, T: float, d: float, 
         sigma: float, v: float) -> float:
    """
    Position of a person in the queue at time t (dimensionless).
    
    Parameters
    ----------
    t : float
        Current time
    l : float
        Step size
    Ts : float
        Step duration
    n : int
        Person index
    T : float
        Total time
    d : float
        Delay between people
    sigma : float
        Random spacing jitter
    v : float
        Movement velocity
        
    Returns
    -------
    float
        Position at time t (returns inf if invalid)
    """
    # Effective step duration including motion
    Tf = Ts + (l / v) if v != 0.0 else Ts
    
    N = math.ceil((t - n * (Tf + d)) / Tf)
    
    if N < 0:
        return math.inf
    if N * Tf > T:
        return math.inf
    
    # Optional random spacing
    jitter = 0.0
    if sigma != 0.0:
        jitter = np.random.normal(0.0, 1.0)
    
    base = N * (l + sigma * jitter)
    
    # After waiting Ts, person moves with speed v
    threshold = (N - 1 + n) * Tf + Ts
    if t > threshold:
        return base + v * (t - ((N - 1 + n) * Tf + Ts))
    else:
        return base

# ------------------------------
# Exhaled particle field integrand
# ------------------------------
@njit(cache=True, fastmath=True)
def _integrand_exhaled(ttag: float, x: float, x0: float, Ts: float, l: float, 
                       T: float, t_final: float, power: float, d: float, 
                       sigma: float, v: float) -> float:
    """
    Integrand for exhaled particle field calculation.
    
    Parameters
    ----------
    ttag : float
        Integration variable (emission time lag)
    x : float
        Observation position
    x0 : float
        Source size scale
    Ts : float
        Step duration
    l : float
        Step size
    T : float
        Total time
    t_final : float
        Observation time
    power : float
        Dimension-dependent power (0.5 for 1D, 1.5 for 3D)
    d : float
        Delay
    sigma : float
        Jitter
    v : float
        Velocity
        
    Returns
    -------
    float
        Integrand value
    """
    if ttag <= 0.0 or ttag >= t_final:
        return 0.0
    
    # Position of exhaler at emission time t - ttag
    px = _pos(t_final - ttag, l, Ts, 0, T, d, sigma, v)
    dx = x - px
    
    return (math.exp(-2.0 * x0 * x0 / ttag) * 
            math.exp(-ttag - dx * dx / ttag) / (ttag ** power))

# ------------------------------
# Exhaled particle profile integration
# ------------------------------
@njit(cache=True, fastmath=True)
def _integrate_exhaled_0_t(t_final: float, x: float, x0: float, Ts: float, 
                           l: float, T: float, power: float, d: float, 
                           sigma: float, v: float, glx: np.ndarray, 
                           glw: np.ndarray) -> float:
    """
    Integrate exhaled field over [0, t_final] using Gauss-Legendre.
    
    Parameters
    ----------
    t_final : float
        Observation time
    x : float
        Observation position
    x0 : float
        Source scale
    Ts : float
        Step duration
    l : float
        Step size
    T : float
        Total time
    power : float
        Dimension power
    d : float
        Delay
    sigma : float
        Jitter
    v : float
        Velocity
    glx : np.ndarray
        GL nodes
    glw : np.ndarray
        GL weights
        
    Returns
    -------
    float
        Integrated exhaled concentration
    """
    if t_final <= 0.0:
        return 0.0
    half = 0.5 * t_final
    mid = half
    acc = 0.0
    for i in range(glx.size):
        ttag = half * glx[i] + mid
        acc += glw[i] * _integrand_exhaled(ttag, x, x0, Ts, l, T, t_final, 
                                           power, d, sigma, v)
    return half * acc

# ------------------------------
# Vectorized exhaled profile
# ------------------------------
@njit(parallel=True, cache=True, fastmath=True)
def _exhaled_profile(x0: float, xa: np.ndarray, Ts: float, l: float, T: float,
                     position: float, power: float, d: float, sigma: float, 
                     v: float, glx: np.ndarray, glw: np.ndarray) -> np.ndarray:
    """
    Compute exhaled particle profile for all positions in xa (parallel).
    
    Parameters
    ----------
    x0 : float
        Source scale
    xa : np.ndarray
        Array of observation positions
    Ts : float
        Step duration
    l : float
        Step size
    T : float
        Total time
    position : float
        Normalized position parameter
    power : float
        Dimension power
    d : float
        Delay
    sigma : float
        Jitter
    v : float
        Velocity
    glx : np.ndarray
        GL nodes
    glw : np.ndarray
        GL weights
        
    Returns
    -------
    np.ndarray
        Exhaled concentration at each position
    """
    t_final = position / l * Ts
    if t_final < 0.1:
        return np.zeros_like(xa, dtype=np.float64)
    
    out = np.empty_like(xa, dtype=np.float64)
    for i in prange(xa.size):
        x = xa[i]
        out[i] = _integrate_exhaled_0_t(t_final, x, x0, Ts, l, T, power, 
                                        d, sigma, v, glx, glw)
    return out

# ------------------------------
# High-level exhaled function
# ------------------------------
def exhaled(x0: float, xa: np.ndarray, Ts: float, l: float, T: float, 
            position: float, dim: str = "3D", d: float = 0.0, 
            sigma: float = 0.0, v: float = 0.0) -> np.ndarray:
    """
    Compute exhaled particle concentration profile.
    
    Parameters
    ----------
    x0 : float
        Source size scale (dimensionless)
    xa : np.ndarray
        Array of observation positions
    Ts : float
        Step duration (dimensionless)
    l : float
        Step size (dimensionless)
    T : float
        Total time (dimensionless)
    position : float
        Normalized position parameter
    dim : str, optional
        Dimension ("1D" or "3D"), by default "3D"
    d : float, optional
        Delay between people, by default 0.0
    sigma : float, optional
        Random spacing jitter, by default 0.0
    v : float, optional
        Movement velocity, by default 0.0
        
    Returns
    -------
    np.ndarray
        Exhaled concentration at each position
        
    Raises
    ------
    ValueError
        If dim is not "1D" or "3D"
    """
    if dim == "1D":
        power = 0.5
    elif dim == "3D":
        power = 1.5
    else:
        raise ValueError("dim must be '1D' or '3D'")
    
    return _exhaled_profile(x0, xa.astype(np.float64), float(Ts), float(l), 
                           float(T), float(position), float(power), float(d), 
                           float(sigma), float(v), _GLX32, _GLW32)

# ------------------------------
# Physical constants and parameters
# ------------------------------
def get_physical_constants() -> dict:
    """
    Return dictionary of physical constants used in the model.
    
    Returns
    -------
    dict
        Physical constants with keys:
        - D: Diffusion coefficient (m^2/s)
        - k: Decay rate (1/s)
        - r0: Characteristic length scale sqrt(4D/k) (m)
    """
    D = 3.8e-3   # m^2/s
    k = 0.9e-3   # 1/s
    r0 = math.sqrt(4.0 * D / k)
    return {'D': D, 'k': k, 'r0': r0}

# ------------------------------
# Export Gauss-Legendre nodes/weights
# ------------------------------
def get_gauss_legendre_16() -> Tuple[np.ndarray, np.ndarray]:
    """Return 16-point Gauss-Legendre nodes and weights."""
    return _GLX16.copy(), _GLW16.copy()

def get_gauss_legendre_32() -> Tuple[np.ndarray, np.ndarray]:
    """Return 32-point Gauss-Legendre nodes and weights."""
    return _GLX32.copy(), _GLW32.copy()

# ------------------------------
# Figure 1 - Queue dynamics visualization helpers
# ------------------------------
def pos_exh_abs(t: float, Delta: float, t_step: float, x_init: float) -> float:
    """
    Position of exhaler at time t (stepwise function).
    
    Parameters
    ----------
    t : float
        Current time
    Delta : float
        Spatial step size
    t_step : float
        Time duration of each step
    x_init : float
        Initial position
        
    Returns
    -------
    float
        Position at time t
    """
    if t <= 0.0:
        return x_init
    step_index = int(np.floor(t / t_step))
    return x_init + step_index * Delta

def F_at_pixel(t_now: float, x: float, x0_len: float, power: float, 
               Delta: float, t_step: float, initial_pos: float,
               d_offset: float = 0.4, D_val: float = 0.01, 
               k_val: float = 1.0) -> float:
    """
    Compute instantaneous aerosol field at position x and time t_now.
    Integrates over emission history with moving emitter.
    
    Parameters
    ----------
    t_now : float
        Current time
    x : float
        Position to evaluate
    x0_len : float
        Small-source regularization parameter
    power : float
        Dimension parameter (1.5 for 3D, 0.5 for 1D)
    Delta : float
        Spatial step size
    t_step : float
        Time duration of each step
    initial_pos : float
        Initial position of emitter
    d_offset : float, optional
        Offset distance from person (default 0.4)
    D_val : float, optional
        Diffusion coefficient (default 0.01)
    k_val : float, optional
        Decay rate (default 1.0)
        
    Returns
    -------
    float
        Aerosol concentration at (x, t_now)
    """
    from scipy.integrate import quad
    
    if t_now <= 0.0:
        return 0.0
    
    def integrand(tau: float) -> float:
        # Emitter position at emission time
        x_emit = d_offset + pos_exh_abs(t_now - tau, Delta, t_step, initial_pos)
        r = x - x_emit
        
        # Small-source regularization
        if x0_len > 0.0:
            reg = np.exp(-2.0 * x0_len * x0_len / (4.0 * D_val * max(tau, 1e-16)))
        else:
            reg = 1.0
        
        return reg * np.exp(-k_val * tau - (r * r) / (4.0 * D_val * max(tau, 1e-16))) / \
               ((4.0 * np.pi * D_val * max(tau, 1e-16)) ** power)
    
    # Break points where emitter position changes (steps)
    nmax = int(np.floor(t_now / t_step))
    breaks = [t_now - n * t_step for n in range(1, nmax + 1)]
    breaks = [b for b in breaks if 0.0 < b < t_now]
    
    acc, err = quad(integrand, 0.0, t_now, points=breaks, limit=400, 
                   epsabs=1e-10, epsrel=1e-8)
    return acc

def build_aerosol_field(t_min: float, t_max: float, Nt: int, 
                        x_min: float, x_max: float, Nx: int, 
                        x0_len: float, power: float,
                        Delta: float, t_step: float, initial_pos: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Build the full 2D aerosol concentration field for queue visualization.
    
    Parameters
    ----------
    t_min, t_max : float
        Time range
    Nt : int
        Number of time points
    x_min, x_max : float
        Position range
    Nx : int
        Number of position points
    x0_len : float
        Small-source regularization parameter
    power : float
        Dimension parameter (1.5 for 3D, 0.5 for 1D)
    Delta : float
        Spatial step size
    t_step : float
        Time duration of each step
    initial_pos : float
        Initial position of emitter
        
    Returns
    -------
    ts : np.ndarray
        Time grid
    xs : np.ndarray
        Position grid
    F : np.ndarray
        2D aerosol concentration field (Nx, Nt)
    """
    ts = np.linspace(t_min, t_max, Nt)
    xs = np.linspace(x_min, x_max, Nx)
    F = np.zeros((Nx, Nt), dtype=float)
    
    for i, t_now in enumerate(ts):
        for j, x in enumerate(xs):
            F[j, i] = F_at_pixel(t_now, x, x0_len, power, Delta, t_step, initial_pos)
    
    return ts, xs, F

# ------------------------------
# Figure 4A - Numerical vs analytical comparison
# ------------------------------
def compute_figure4A_data(tss: np.ndarray, T: float, l: float, 
                         eps: float, a_vals: np.ndarray,
                         k: float = 0.9e-3) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute data for Figure 4A: numerical vs analytical comparison.
    
    Parameters
    ----------
    tss : np.ndarray
        Array of step times (dimensionless)
    T : float
        Total observation time
    l : float
        Spatial step parameter
    eps : float
        Small time regularization
    a_vals : np.ndarray
        Array of particle size parameters
    k : float, optional
        Decay rate (default 0.9e-3)
        
    Returns
    -------
    Tss : np.ndarray
        Normalized step times
    numerical : np.ndarray
        Numerical integration results (integrated over a)
    analytical : np.ndarray
        Analytical approximation
    """
    # Get Gauss-Legendre quadrature
    glx, glw = get_gauss_legendre_16()
    
    # Normalized step times
    Tss = k * tss
    
    # Compute numerical results for all (Tss, a) pairs
    result_ar = compute_results_multiple_a(Tss.astype(np.float64), a_vals, T, l, eps, glx, glw)
    
    # Integrate over a (weighted by a^2)
    numerical = np.trapezoid(result_ar * a_vals**2, a_vals, axis=1)
    
    # Analytical approximation
    analytical = (T/Tss) * (1 - np.exp(-Tss))**2 / 2.2
    
    return Tss, numerical, analytical

