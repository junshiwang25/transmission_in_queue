"""
Aerosol transport model for a queue.

Notation follows the manuscript:
    d        forward offset of the effective source from the mouth
    Delta    spacing between consecutive people in the queue
    t_step   time each person spends at one position
    t_tot    total time spent in the queue
    d_star   decay length sqrt(4D/k)
    m        index of a segment / of a previously occupied position

Unless noted otherwise, lengths are in units of d_star and times in units of 1/k.
"""

import math
import numpy as np
from numba import njit, prange
from typing import Tuple

# Gauss-Legendre nodes and weights on [-1, 1]
_GLX16 = np.array([
    -0.9894009349916499, -0.9445750230732326, -0.8656312023878317, -0.7554044083550030,
    -0.6178762444026438, -0.4580167776572274, -0.2816035507792589, -0.09501250983763744,
     0.09501250983763744,  0.2816035507792589,  0.4580167776572274,  0.6178762444026438,
     0.7554044083550030,  0.8656312023878317,  0.9445750230732326,  0.9894009349916499
], dtype=np.float64)

_GLW16 = np.array([
    0.027152459411754095, 0.06225352393864789, 0.09515851168249278, 0.12462897125553387,
    0.14959598881657673, 0.16915651939500254, 0.1826034150449236,  0.1894506104550685,
    0.1894506104550685,  0.1826034150449236,  0.16915651939500254, 0.14959598881657673,
    0.12462897125553387, 0.09515851168249278, 0.06225352393864789, 0.027152459411754095
], dtype=np.float64)

_GLX32 = np.array([
    -0.997263861849, -0.985611511545, -0.964762255588, -0.934906075938,
    -0.896321155766, -0.849367613733, -0.794483795968, -0.732182118740,
    -0.663044266930, -0.587715757241, -0.506899908932, -0.421351276131,
    -0.331868602282, -0.239287362252, -0.144471961583, -0.048307665688,
     0.048307665688,  0.144471961583,  0.239287362252,  0.331868602282,
     0.421351276131,  0.506899908932,  0.587715757241,  0.663044266930,
     0.732182118740,  0.794483795968,  0.849367613733,  0.896321155766,
     0.934906075938,  0.964762255588,  0.985611511545,  0.997263861849
], dtype=np.float64)

_GLW32 = np.array([
    0.007018610009, 0.016274394715, 0.025392065309, 0.034273862913,
    0.042835898022, 0.050998059262, 0.058684093479, 0.065822222776,
    0.072345794109, 0.078193895787, 0.083311924227, 0.087652093004,
    0.091173878696, 0.093844399081, 0.095638720079, 0.096540088515,
    0.096540088515, 0.095638720079, 0.093844399081, 0.091173878696,
    0.087652093004, 0.083311924227, 0.078193895787, 0.072345794109,
    0.065822222776, 0.058684093479, 0.050998059262, 0.042835898022,
    0.034273862913, 0.025392065309, 0.016274394715, 0.007018610009
], dtype=np.float64)


# ---------------------------------------------------------------------------
# Inhaled particle number: segment-wise evaluation of Eq. (13)
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True)
def _g(m: int, t: float, Delta: float, d: float) -> float:
    """g_m(t) of Eq. (12), at separation Delta_m = |m*Delta - d|."""
    Delta_m = abs(m * Delta - d)

    # Guards against overflow and against the Delta_m -> 0 singularity
    if Delta_m > 70.0:
        return 0.0
    if t < 1e-6:
        return 0.0
    if Delta_m < 1e-12:
        return 0.0

    rt = math.sqrt(t)
    e4 = math.exp(4.0 * Delta_m)
    term = (1.0 - e4
            + math.erf((Delta_m - t) / rt)
            + e4 * math.erf((Delta_m + t) / rt))
    return -(math.exp(-2.0 * Delta_m) * math.sqrt(math.pi) * term) / (2.0 * Delta_m)


@njit(cache=True, fastmath=True)
def _integrand(tau: float, seg_index: int, t_step: float, Delta: float,
               d: float, eps: float, M: int = 10) -> float:
    """Bracketed term of Eq. (13): the m = -1 contribution plus the sum over m."""
    mmax = min(seg_index, M)

    y = _g(-1, tau, Delta, d) - _g(-1, eps, Delta, d)
    for m in range(mmax + 1):
        y += _g(m, tau + (m + 1) * t_step, Delta, d) - _g(m, tau + m * t_step, Delta, d)
    return y


@njit(cache=True, fastmath=True)
def _integrate_segment(seg_index: int, t_step: float, Delta: float, d: float,
                       eps: float, seg_len: float, glx: np.ndarray,
                       glw: np.ndarray, M: int = 10) -> float:
    """Gauss-Legendre integration of _integrand over one segment of length seg_len."""
    if seg_len <= 0.0:
        return 0.0
    half = 0.5 * seg_len
    acc = 0.0
    for i in range(glx.size):
        tau = half * glx[i] + half
        acc += glw[i] * _integrand(tau, seg_index, t_step, Delta, d, eps, M)
    return half * acc


@njit(cache=True, fastmath=True)
def _integrate_total(t_tot: float, t_step: float, Delta: float, d: float,
                     eps: float, glx: np.ndarray, glw: np.ndarray,
                     M: int = 10) -> float:
    """
    Integrate Eq. (13) over [0, t_tot].

    Only the first M positions behind the source are resolved individually;
    beyond that the per-segment contribution is taken to have saturated and the
    remaining segments reuse a single periodic value.
    """
    if t_tot <= 0.0:
        return 0.0

    total = 0.0

    # Segments before saturation
    n_segments = int(t_tot // t_step)
    n_init = n_segments if n_segments < M else M

    for s in range(n_init):
        seg_start = s * t_step
        seg_end = seg_start + t_step
        if seg_end > t_tot:
            seg_end = t_tot
        seg_len = seg_end - seg_start
        if seg_len > 0.0:
            total += _integrate_segment(s, t_step, Delta, d, eps, seg_len, glx, glw, M)

    t_done = n_init * t_step
    if t_done >= t_tot:
        return total

    # After saturation: one periodic segment value, repeated
    period_val = _integrate_segment(M, t_step, Delta, d, eps, t_step, glx, glw, M)

    t_left = t_tot - t_done
    n_full = int(t_left // t_step)
    total += n_full * period_val

    rem = t_left - n_full * t_step
    if rem > 0.0:
        total += _integrate_segment(M, t_step, Delta, d, eps, rem, glx, glw, M)

    return total


@njit(parallel=True, cache=True, fastmath=True)
def compute_Ntot(t_steps: np.ndarray, t_tot: float, Delta: float, d: float,
                 eps: float, glx: np.ndarray, glw: np.ndarray,
                 M: int = 10) -> np.ndarray:
    """Inhaled particle number for each t_step in t_steps (Figs. 4D, 5)."""
    N = np.zeros(t_steps.size, dtype=np.float64)
    for i in prange(t_steps.size):
        N[i] = _integrate_total(t_tot, t_steps[i], Delta, d, eps, glx, glw, M)
    return N


@njit(parallel=True, cache=True, fastmath=True)
def compute_Ntot_multi_d(t_steps: np.ndarray, d_vals: np.ndarray, t_tot: float,
                         Delta: float, eps: float, glx: np.ndarray,
                         glw: np.ndarray) -> np.ndarray:
    """
    Inhaled particle number on the (t_step, d) grid (Figs. 4A, 4C).

    Returns an array of shape (t_steps.size, d_vals.size).
    """
    out = np.zeros((t_steps.size, d_vals.size), dtype=np.float64)
    for j in prange(d_vals.size):
        d = d_vals[j]
        for i in range(t_steps.size):
            # NOTE: M is fixed at 10 here.
            out[i, j] = _integrate_total(t_tot, t_steps[i], Delta, d, eps, glx, glw, 10)
    return out


# ---------------------------------------------------------------------------
# Spatial profile of exhaled particles (Fig. 4B)
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True)
def _pos(t: float, Delta: float, t_step: float, n: int, t_tot: float) -> float:
    """
    Position of person n at time t: they occupy site N*Delta throughout step N.

    Returns inf before the person has entered the queue and after t_tot.
    """
    N = math.ceil((t - n * t_step) / t_step)
    if N < 0:
        return math.inf
    if N * t_step > t_tot:
        return math.inf
    return N * Delta


@njit(cache=True, fastmath=True)
def _integrand_exhaled(t_prime: float, x: float, source_width: float,
                       t_step: float, Delta: float, t_tot: float,
                       t_now: float, power: float) -> float:
    """Integrand of Eq. (4) for a source that steps forward, at time lag t_prime."""
    if t_prime <= 0.0 or t_prime >= t_now:
        return 0.0

    x_source = _pos(t_now - t_prime, Delta, t_step, 0, t_tot)
    dx = x - x_source

    return (math.exp(-2.0 * source_width * source_width / t_prime) *
            math.exp(-t_prime - dx * dx / t_prime) / (t_prime ** power))


@njit(cache=True, fastmath=True)
def _integrate_exhaled(t_now: float, x: float, source_width: float, t_step: float,
                       Delta: float, t_tot: float, power: float,
                       glx: np.ndarray, glw: np.ndarray) -> float:
    """Gauss-Legendre integration of _integrand_exhaled over [0, t_now]."""
    if t_now <= 0.0:
        return 0.0
    half = 0.5 * t_now
    acc = 0.0
    for i in range(glx.size):
        t_prime = half * glx[i] + half
        acc += glw[i] * _integrand_exhaled(t_prime, x, source_width, t_step,
                                           Delta, t_tot, t_now, power)
    return half * acc


@njit(parallel=True, cache=True, fastmath=True)
def _exhaled_profile(source_width: float, x: np.ndarray, t_step: float,
                     Delta: float, t_tot: float, x_infected: float,
                     power: float, glx: np.ndarray, glw: np.ndarray) -> np.ndarray:
    """Profile at the moment the infected person reaches x_infected."""
    t_now = x_infected / Delta * t_step
    if t_now < 0.1:
        return np.zeros_like(x, dtype=np.float64)

    out = np.empty_like(x, dtype=np.float64)
    for i in prange(x.size):
        out[i] = _integrate_exhaled(t_now, x[i], source_width, t_step, Delta,
                                    t_tot, power, glx, glw)
    return out


def exhaled(source_width: float, x: np.ndarray, t_step: float, Delta: float,
            t_tot: float, x_infected: float, dim: str = "3D") -> np.ndarray:
    """
    Concentration of exhaled particles along x, at the time the infected person
    stands at x_infected.

    source_width regularizes the point source; dim selects the 1D or 3D kernel.
    """
    if dim == "1D":
        power = 0.5
    elif dim == "3D":
        power = 1.5
    else:
        raise ValueError("dim must be '1D' or '3D'")

    return _exhaled_profile(float(source_width), x.astype(np.float64),
                            float(t_step), float(Delta), float(t_tot),
                            float(x_infected), float(power), _GLX32, _GLW32)


# ---------------------------------------------------------------------------
# Parameters and quadrature accessors
# ---------------------------------------------------------------------------

def get_physical_constants() -> dict:
    """Diffusion coefficient D (m^2/s), decay rate k (1/s), decay length d_star (m)."""
    D = 3.8e-3
    k = 0.9e-3
    return {'D': D, 'k': k, 'd_star': math.sqrt(4.0 * D / k)}


def get_gauss_legendre_16() -> Tuple[np.ndarray, np.ndarray]:
    """16-point Gauss-Legendre nodes and weights."""
    return _GLX16.copy(), _GLW16.copy()


# ---------------------------------------------------------------------------
# Aerosol field for the queue schematic (Fig. 1)
# ---------------------------------------------------------------------------

def _infected_position(t: float, Delta: float, t_step: float, x_init: float) -> float:
    """Position of the infected person at time t (piecewise constant)."""
    if t <= 0.0:
        return x_init
    return x_init + int(np.floor(t / t_step)) * Delta


def _field_at(t: float, x: float, source_width: float, power: float,
              Delta: float, t_step: float, x_init: float,
              d: float = 0.4, D: float = 0.01, k: float = 1.0) -> float:
    """Concentration at (x, t) from a stepping source, in dimensional units."""
    from scipy.integrate import quad

    if t <= 0.0:
        return 0.0

    def integrand(tau: float) -> float:
        x_source = d + _infected_position(t - tau, Delta, t_step, x_init)
        r = x - x_source

        if source_width > 0.0:
            reg = np.exp(-2.0 * source_width ** 2 / (4.0 * D * max(tau, 1e-16)))
        else:
            reg = 1.0

        return reg * np.exp(-k * tau - (r * r) / (4.0 * D * max(tau, 1e-16))) / \
               ((4.0 * np.pi * D * max(tau, 1e-16)) ** power)

    # Break the integral at the times the source steps forward
    nmax = int(np.floor(t / t_step))
    breaks = [t - n * t_step for n in range(1, nmax + 1)]
    breaks = [b for b in breaks if 0.0 < b < t]

    acc, _ = quad(integrand, 0.0, t, points=breaks, limit=400,
                  epsabs=1e-10, epsrel=1e-8)
    return acc


def build_aerosol_field(t_min: float, t_max: float, Nt: int,
                        x_min: float, x_max: float, Nx: int,
                        source_width: float, power: float,
                        Delta: float, t_step: float,
                        x_init: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Concentration field on a (x, t) grid for the queue schematic.

    Returns the time grid, the position grid, and the field with shape (Nx, Nt).
    """
    ts = np.linspace(t_min, t_max, Nt)
    xs = np.linspace(x_min, x_max, Nx)
    F = np.zeros((Nx, Nt), dtype=float)

    for i, t in enumerate(ts):
        for j, x in enumerate(xs):
            F[j, i] = _field_at(t, x, source_width, power, Delta, t_step, x_init)

    return ts, xs, F


# ---------------------------------------------------------------------------
# Fig. 4A: numerical result against the D -> 0 limit
# ---------------------------------------------------------------------------

def compute_figure4A_data(t_step_seconds: np.ndarray, t_tot: float, Delta: float,
                          eps: float, d_vals: np.ndarray,
                          k: float = 0.9e-3) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Numerical result of Eq. (19) and the analytic limit of Eq. (18).

    The numerical curve is the spatial integral over d, weighted by d^2.
    """
    glx, glw = get_gauss_legendre_16()

    t_steps = k * t_step_seconds

    Ntot_grid = compute_Ntot_multi_d(t_steps.astype(np.float64), d_vals,
                                     t_tot, Delta, eps, glx, glw)
    numerical = np.trapezoid(Ntot_grid * d_vals ** 2, d_vals, axis=1)

    analytical = (t_tot / t_steps) * (1 - np.exp(-t_steps)) ** 2 / 2.2

    return t_steps, numerical, analytical
